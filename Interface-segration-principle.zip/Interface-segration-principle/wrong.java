public class wrong {
    // One fat interface
interface SchoolDuties {
    void teach();
    void markAttendance();
    void attendClass();
    void playSport();
}

// Now every class is forced to implement all methods, even if not needed
class Teacher implements SchoolDuties {
    public void teach() {
        System.out.println("Teaching subjects.");
    }

    public void markAttendance() {
        System.out.println("Marking student attendance.");
    }

    public void attendClass() {
        // Not applicable
        throw new UnsupportedOperationException("Teachers don't attend class as students.");
    }

    public void playSport() {
        // Not applicable
        throw new UnsupportedOperationException("Teachers don't play sports as part of duty.");
    }
}

class Student implements SchoolDuties {
    public void teach() {
        // Not applicable
        throw new UnsupportedOperationException("Students don't teach.");
    }

    public void markAttendance() {
        // Not applicable
        throw new UnsupportedOperationException("Students don't mark attendance.");
    }

    public void attendClass() {
        System.out.println("Attending class.");
    }

    public void playSport() {
        // Optional or not applicable
        throw new UnsupportedOperationException("Not all students play sports.");
    }
}

class Coach implements SchoolDuties {
    public void teach() {
        // Not applicable
        throw new UnsupportedOperationException("Coaches don't teach academics.");
    }

    public void markAttendance() {
        // Not applicable
        throw new UnsupportedOperationException("Coaches don't mark attendance.");
    }

    public void attendClass() {
        // Not applicable
        throw new UnsupportedOperationException("Coaches don't attend class.");
    }

    public void playSport() {
        System.out.println("Coaching sports.");
    }
}
}
